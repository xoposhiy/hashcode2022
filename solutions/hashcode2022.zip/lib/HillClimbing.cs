using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace bot;

public class HillClimbing<TProblem, TSolution> : ISolver<TProblem, TSolution>
    where TSolution : class, ISolution
{
    private readonly ISolver<TProblem, TSolution> baseSolver;
    private readonly double baseSolverTimeFraction;
    public readonly StatValue BestSolutionTimeMs = StatValue.CreateEmpty();
    public readonly StatValue ImprovementsCount = StatValue.CreateEmpty();
    protected readonly IMutator<TProblem, TSolution> Mutator;
    public readonly StatValue SimulationsCount = StatValue.CreateEmpty();

    public HillClimbing(
        ISolver<TProblem, TSolution> baseSolver,
        IMutator<TProblem, TSolution> mutator,
        double baseSolverTimeFraction = 0.1)
    {
        this.baseSolver = baseSolver;
        Mutator = mutator;
        this.baseSolverTimeFraction = baseSolverTimeFraction;
    }

    [SuppressMessage("ReSharper", "SuspiciousTypeConversion.Global")]
    public IEnumerable<TSolution> GetSolutions(TProblem problem, Countdown countdown)
    {
        var mutationsCount = 0;
        var improvementsCount = 0;
        var baseSolution = baseSolver.GetSolutions(problem, countdown * baseSolverTimeFraction).Last();
        var steps = new List<TSolution> { baseSolution };
        while (!countdown.IsFinished())
        {
            var improvements = TryImprove(problem, steps.Last());
            mutationsCount++;
            foreach (var solution in improvements)
            {
                improvementsCount++;
                solution.DebugInfo = new SolutionDebugInfo(countdown, mutationsCount, improvementsCount, ToString());
                steps.Add(solution);
            }
        }

        SimulationsCount.Add(mutationsCount);
        ImprovementsCount.Add(improvementsCount);
        if (steps.Count > 0)
            BestSolutionTimeMs.Add(steps.Last().DebugInfo.Time.TotalMilliseconds);
        return steps;
    }

    public string GetDebugStats()
    {
        return new[]
        {
            $"sims: {SimulationsCount.ToDetailedString()}",
            $"imps: {ImprovementsCount.ToDetailedString()}",
            $"time: {BestSolutionTimeMs.ToDetailedString()}"
        }.StrJoin("\n");
    }

    public override string ToString()
    {
        return $"HC_({Mutator})_({baseSolver})_{baseSolverTimeFraction:#%}";
    }

    protected IEnumerable<TSolution> TryImprove(TProblem problem, TSolution bestSolution)
    {
        var mutation = Mutator.Mutate(problem, bestSolution);
        if (!(mutation.Score > bestSolution.Score)) yield break;
        bestSolution = mutation.GetResult();
        yield return bestSolution;
    }
}